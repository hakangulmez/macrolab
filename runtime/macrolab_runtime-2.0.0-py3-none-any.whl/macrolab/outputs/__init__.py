"""Validated model output extensions."""
