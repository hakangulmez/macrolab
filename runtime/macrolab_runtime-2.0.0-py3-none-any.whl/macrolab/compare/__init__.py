"""Descriptive cross-country comparisons."""
