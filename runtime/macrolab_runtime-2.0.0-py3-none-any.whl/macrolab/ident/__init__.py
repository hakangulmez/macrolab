"""Reusable identified shock series."""
